package com.kiran.entity;

public enum ServiceType {

	LANDLINE, MOBILE, FIBER_OPTIC;
}

