package com.kiran.entity;

public enum Status {
	
	RAISED, ASSIGNED, WIP, RESOLVED, ESCALATED;
	

}
